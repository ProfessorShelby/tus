import TusSearchPage from '@/components/TusSearchPage';

export default function Home() {
  return <TusSearchPage />;
}
