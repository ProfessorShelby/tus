CREATE TABLE `hastaneler` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`kurum_kodu` integer NOT NULL,
	`hastane_adi` text NOT NULL,
	`tip` text NOT NULL,
	`kurum_tipi` text NOT NULL,
	`sehir` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `hastaneler_kurum_kodu_unique` ON `hastaneler` (`kurum_kodu`);--> statement-breakpoint
CREATE INDEX `idx_hastaneler_sehir` ON `hastaneler` (`sehir`);--> statement-breakpoint
CREATE INDEX `idx_hastaneler_tip` ON `hastaneler` (`tip`);--> statement-breakpoint
CREATE INDEX `idx_hastaneler_kurum_tipi` ON `hastaneler` (`kurum_tipi`);--> statement-breakpoint
CREATE TABLE `tus_puanlar` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`kurum_kodu` integer NOT NULL,
	`kade_te_kisa_adi` text NOT NULL,
	`kademe` text NOT NULL,
	`brans` text NOT NULL,
	`donem` text NOT NULL,
	`donem_tarihi` text NOT NULL,
	`kontenjan` integer NOT NULL,
	`yerlesen` integer NOT NULL,
	`karsilanamayan_kontenjan` integer NOT NULL,
	`taban_puan` real,
	`tavan_puan` real,
	`taban_siralamasi` integer
);
--> statement-breakpoint
CREATE INDEX `idx_tus_puanlar_kurum_kodu` ON `tus_puanlar` (`kurum_kodu`);--> statement-breakpoint
CREATE INDEX `idx_tus_puanlar_brans` ON `tus_puanlar` (`brans`);--> statement-breakpoint
CREATE INDEX `idx_tus_puanlar_donem` ON `tus_puanlar` (`donem`);--> statement-breakpoint
CREATE INDEX `idx_tus_puanlar_taban_puan` ON `tus_puanlar` (`taban_puan`);--> statement-breakpoint
CREATE INDEX `idx_tus_puanlar_kontenjan` ON `tus_puanlar` (`kontenjan`);